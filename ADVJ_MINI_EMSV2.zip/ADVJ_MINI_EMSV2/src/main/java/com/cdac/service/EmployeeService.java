package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cdac.dao.EmployeeDao;
import com.cdac.entity.Employee;

@Component
public class EmployeeService {
	
	@Autowired
	private EmployeeDao employeedao;
	
	public void save(Employee employee) {
		
		employeedao.add(employee);
		
	}
	
	public List<Employee> display(){
		
		List<Employee> listemp = employeedao.fetchAll();
		
		//System.out.println(listemp);
		
		return listemp;
	}
	
	
	public void removeEmp(int id) {
		
		Employee employee = employeedao.getEmpById(id);
		employeedao.delete(employee);
	}
	
	public Employee empById(int id) {
		Employee employee = employeedao.getEmpById(id);
		return employee;
	}
	
	public void updateEmp(Employee employee) {
		
		employeedao.rewrite(employee);
	}
	
	
	//==================================================================
     public boolean validAdmin(String username, String password) {
		
		if(username.equals("admin")&& password.equals("password"))
			return true;
		return false;
		
	}
     
     
     public boolean validEmp(int empid, String password) {
    	 boolean status= false;
    	 List<Employee> listemp = employeedao.fetchAll();
    	 
    	 for (Employee employee : listemp) {
			if(empid == employee.getId()&& password.equals(employee.getPassword())) {
				status= true;
				break;
			}
		}
 		return status;
 		
 	}
     
     public long deptCount(String department) {
    	 
    	long count = employeedao.getDeptCount(department);
    	return count;
     }
     
	

}
