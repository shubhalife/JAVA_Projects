package com.cdac.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

import com.cdac.entity.Employee;

@Component
public class EmployeeDao {
	
	@PersistenceContext
	private EntityManager et;
	
	@Transactional
	public void add(Employee employee) {
		et.persist(employee);
	}
	
	
	public List<Employee> fetchAll(){
		return et
				.createQuery("select c from Employee c", Employee.class)
				.getResultList();
		
	}
	
	@Transactional
	public void delete(Employee employee) {
		et.remove(et.contains(employee) ? employee : et.merge(employee));
		
	}
	
	
	@Transactional
	public Employee getEmpById(int id)
	{
		Employee emp= et.find(Employee.class, id);
		//System.out.println(emp.getCity());
		return emp;
	}
	
	
	@Transactional
	public void rewrite(Employee employee) {
		et.merge(employee);
	}
	
	public Long getDeptCount(String department) {
		Query query = et.createQuery("select count(c) from Employee c where c.department = :dept");
		query.setParameter("dept", department);
		Long count = (Long) query.getSingleResult();
		return count;
				
	}
	
	
}
