package com.cdac.controller;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.cdac.entity.Employee;
import com.cdac.service.EmployeeService;

@Controller
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	//index page mapping
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	  // to adminlogin page from index.jsp
	@RequestMapping("/adminlogin")
	public String toadminLogin(Model m) {
		return "adminlogin";
	}
	
	
	//to admin page from adminlogin hit button
	@RequestMapping("/adminweb")
	public String adminLogin(HttpServletRequest request,  Model m) {
			String username = request.getParameter("adminname");
			String password = request.getParameter("adminpass");
			if(employeeService.validAdmin(username, password)) {
				
				 HttpSession session=request.getSession();  
			        session.setAttribute("name", username); 
			        
				
				return "admin";
			}
			else{
				m.addAttribute("message", "incorrect username/password");
				return "adminlogin";
			}		
	}
	
	
	//admin page
	@RequestMapping("/admin")
	public String adminWeb(Model m,HttpServletRequest request) {
			HttpSession session = request.getSession();
			String str = (String) session.getAttribute("name");
			if(str!=null && str.equals("admin")) {
			List<Employee> employee1 =employeeService.display();
			m.addAttribute("employee",employee1);
			
			return "admin";
			}
			else {
				return "index";
			}
	}
	
	
	 //piechart 
	  @RequestMapping("/piechart")
	  public String piChartPage(Model m,HttpServletRequest request) {
		    HttpSession session = request.getSession();
			String str = (String) session.getAttribute("name");
			System.out.println(str);
			if(str!=null && str.equals("admin")) {
				 long frontend = employeeService.deptCount("Frontend");
				  long backend =employeeService.deptCount("Backend");
				  long admin =employeeService.deptCount("Admin");
				 
				  m.addAttribute("dept1",frontend);
				  m.addAttribute("dept2", backend);
				  m.addAttribute("dept3", admin);
				  
				  return "piechart";
				
			}else {
				return "index";
			}
		  
	  }
	
	
	//register employee form
	@RequestMapping("/add-employee")
	public String addEmployee(Model m,HttpServletRequest request) {
			HttpSession session = request.getSession();
			String str = (String) session.getAttribute("name");
			if(str!=null) {
			m.addAttribute("title", "AddEmployee");
			return "register";
			}
			else {
				return "index";
			}
	}
	
	
	//add employee register data
	@RequestMapping(value="/handle-employee" , method=RequestMethod.POST) public
	RedirectView handleEmployee(@ModelAttribute Employee
	employee,HttpServletRequest request) {
		 
		  employeeService.save(employee);
	  
		  RedirectView redirectView = new RedirectView();
		  redirectView.setUrl(request.getContextPath() +"/admin");
	  
		  return redirectView; 
	  
	}
	
	//delete employee data
	@GetMapping("/delete/{empId}")
	public RedirectView deleteEmployee(@PathVariable("empId") int empId,HttpServletRequest request) {
		
		  employeeService.removeEmp(empId);
		
		  RedirectView redirectView = new RedirectView();
		  redirectView.setUrl(request.getContextPath() +"/admin");
		  
		  return redirectView;
	}
	
	//to updateform
	@RequestMapping("update/{empId}")
	public String updateEmployee(@PathVariable("empId") int empId,Model m) {
		  Employee employee = employeeService.empById(empId);
		  m.addAttribute("employee",employee);
		
		
		  return "updateform";
	}
	
	//update employee data
	@RequestMapping(value="/update-employee/{empId}" , method=RequestMethod.POST) public
	RedirectView updateDetails(@ModelAttribute Employee
	  employee,HttpServletRequest request,@PathVariable("empId") int empId) { 
		
		 employee.setId(empId);
	     employeeService.updateEmp(employee);
	  
	     RedirectView redirectView = new RedirectView();
	     redirectView.setUrl(request.getContextPath() +"/admin");
	  
	     return redirectView;
	  
	  
   }
	
	
	 
	// to index.jsp
    @RequestMapping("/home")
	public String toHome(HttpServletRequest request) {
		  HttpSession session=request.getSession();  
          session.invalidate();  
		  
		  return "index";
	  }
	
	
	
	
	//===================================================================
	
	 

	//to employeelogin
	@RequestMapping("/emplogin")
	public String toEmpLogin(Model m) {
		
			return "emplogin";
			}
	  
	//to empweb from emplogin
	@RequestMapping("/empweb")
	public String empLogin(HttpServletRequest request,  Model m) {
		  
		  
			int empid = Integer.parseInt(request.getParameter("empid"));
			String password = request.getParameter("emppass");
			
	
			if(employeeService.validEmp(empid, password)) {
				Employee  employee =employeeService.empById(empid);
				m.addAttribute(employee);
				return "empweb1";
			}
			else{
				m.addAttribute("message", "incorrect username/password");
				return "emplogin";
			}
			
	}
	  
	  
	 	  
	  
}//end of employee controller
